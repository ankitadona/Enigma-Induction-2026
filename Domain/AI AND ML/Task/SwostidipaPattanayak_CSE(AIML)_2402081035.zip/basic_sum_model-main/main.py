# imports from the model.py file
from model import read_text_file, summarize_text, output_summary

# the input file path, the model, and the output file path
INPUT_FILE = "input.txt"
MODEL = "facebook/bart-large-cnn"
OUTPUT_FILE = "summary.txt"

# read the text from the input file
text = read_text_file(INPUT_FILE)

# generate the summary using the model
summary = summarize_text(text, model=MODEL)

# output the summary to text file
output_summary(summary, file_path=OUTPUT_FILE)

# outputing to the CLI
print(summary)
